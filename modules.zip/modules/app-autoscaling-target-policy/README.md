# Documentation
## ECS Application Autoscaling Terraform module
 The primary purpose of the module is to setup autoscaling for ECS services. 


## Usage
```hcl
module "ecsservice-autoscaling-target-policy" {
  source = "../../../../modules/ecs-autoscaling/"
  application_name            = var.application_name
  application_stage           = var.application_stage
  terraform_statefile         = var.terraform_statefile
  created_by                  = var.created_by
  support_team                = var.support_team
  autoscaling_info            = var.autoscaling_info
}
```
`application_name`, `application_stage`, `terraform_statefile`, `created_by`, re generic.

 There is 1 complex variable that is key to the functioning of this module.  That is the `autoscaling_info`. Since the top-level is a hash, the top-level hash keys need to be unique.

`autoscaling_info`:

This map variable defines autoscaling info for the ecs services.
```hcl
autoscaling_info = {
  af-tiers-service-CPUUtilization = [
    {
      resource_id        = "service/af-prod-anti-fraud/af-tiers-api"
      service_namespace  = "ecs"
      scalable_dimension = "ecs:service:DesiredCount"
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
      max_capacity = 5
      min_capacity = 2
      target_value = 60
      scale_in_cooldown = 300
      scale_out_cooldown = 300
    }
  ]
  af-tiers-service-MemoryUtilization = [
    {
      resource_id        = "service/af-prod-anti-fraud/af-tiers-api"
      service_namespace  = "ecs"
      scalable_dimension = "ecs:service:DesiredCount"
      predefined_metric_type = "ECSServiceAverageMemoryUtilization"
      max_capacity = 5
      min_capacity = 2
      target_value = 60
      scale_in_cooldown = 300
      scale_out_cooldown = 300
    }
  ]
}
