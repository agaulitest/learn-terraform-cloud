# Documentation
## DocumentDB Terraform module
 The primary purpose of the module is to create documentdb cluster in AWS. 

## Usage
```hcl
module "docdb" {
  source                      = "../../../modules/documentdb/"
  application_name            = var.application_name
  application_stage           = var.application_stage
  terraform_statefile         = var.terraform_statefile
  created_by                  = var.created_by
  support_team                = var.support_team
  biz_division                = var.biz_division
  appid                       = var.appid
  deptcode                    = var.deptcode
  subnet_id_list              = local.private_subnet_id_list
  security_group_ids          = module.security_group.group-id["imageflaredb"]
  docdb_info                  = var.docdb_info
}

```
`application_name`, `application_stage`, `terraform_statefile`, `created_by`, `support_team`, `biz_division`, `appid`, `deptcode` are generic.

 There are three complex variables that are key to the functioning of this module.  They are the `subnet_id_list`, `security_group_ids`, `docdb_info`. Since the top-level is a hash, the top-level hash keys need to be unique.

`subnet_id_list`:

This map variable defines the subnet where the database needs to be provisioned. 
```hcl
subnet_id_list=["subnetid1","subnetid2"]
```
`security_group_ids`:

This map variable defines security groups id for the database instances.

```hcl
security_group_ids=["sg-id1","sg-id2"] 
```
`docdb_info`:

This map variable defines the configuration and properties for documendb instance. 
 
```hcl
docdb_info = {
  documentdb1 = {
    database = {
      engine                      = "docdb"
      engine_version              = "3.6.0"
      port                        = "27017"
      apply_immediately           = true
      dbusername                  = "root"
      dbpassword                  = "changeme"
      backup_retention_period     = 7
      backup_window               = "03:00-04:00"
      maintenance_window          = "Sun:04:00-Sun:05:00"
      storage_encrypted           = true
      deletion_protection         = false
      skip_final_snapshot         = true
    }
    db-parameters-info = {
      family                      = "docdb3.6"
      description                 = "docdb"
    }
    db-parameters = [
      {
        name  = "tls"
        value = "disabled"
        apply_method = "pending-reboot"
      }
    ]
    instance_info = [
      {
        "instance_identifier" = "01"
        "instance_class" = "db.r5.2xlarge"
        "ca_cert_identifier" = ""
        "apply_immediately" = true
      },
      {
        "instance_identifier" = "02"
        "instance_class" = "db.r5.2xlarge"
        "ca_cert_identifier" = ""
        "apply_immediately" = true
      }
    ]
  }
}
```
 
