# Documentation
## AWS Identity and Access Management (IAM) Terraform module
 The primary purpose of the module is to setup IAM Roles and Policies, and to attach them together.  It provides the capability to create custom policies, and also provides for both custom IAM policies and AWS Managed Policies to be attached to a role.
  * Note, this module does NOT create IAM Users or Groups.

## Features
- Define multiple IAM roles and policies inside a single place.

## Usage
```hcl
module "iam" {
  source                     = "../../../modules/iam/"
  application_name           = var.application_name
  application_stage          = var.application_stage
  terraform_statefile        = var.terraform_statefile
  created_by                 = var.created_by
  support_team               = var.support_team
  biz_division               = var.biz_division
  appid                      = var.appid
  deptcode                   = var.deptcode
  iam_assume_role_required   = var.assume_role
  iam_policy_info            = var.policy_info
  iam_target_account_number  = var.aws_account
  iam_policy_attachment_info = var.policy_attachment_info
}
```
`application_name`, `application_stage`, `terraform_statefile`, `created_by`, `owner`, `cost_center`, `aws_account` are generic.

 There are three complex variables that are key to the functioning of this module.  They are the `assume_role`, `policy_info`, `policy_attachment_info`. Since the top-level is a hash, the top-level hash keys need to be unique.

`assume_role`:

This map variable defines the trust relationship of the IAM role. We can include multiple entries inside this variable if we need multiple roles. 
```hcl
assume_role = {
  master = [
    {
      action_list = [
        "sts:AssumeRole"
      ]
      principal_list = [
        {
          identifier_list = [
            "ec2.amazonaws.com"
          ]
          type = "Service"
        }
      ]
      condition = []
    }
  ]
} 
```
`policy_info`:

This map variable defines permissions. Each entry in this variable will create seperate IAM policy in AWS. 
- effect is optional. If not specified, permissions with "allow" action will be created. 

 ```hcl
 policy_info = {
   custom_iam = [
     {
       effect = "Allow"
       action_list = [
           "iam:*InstanceProfile*",
           "iam:*Role*",
           "iam:ListInstanceProfiles",
           "iam:*List*",
           "iam:*Get*",
           "iam:PassRole"
       ]
       resource_list = ["*"]
       condition = []
     },
     {
       effect = "Deny"
       action_list = [
           "iam:*Put*",
           "iam:*Delete*"
       ]
       resource_list = ["*"]
       condition = []
     }
   ]
   custom_billing_portal = [
     {
       effect = "Deny"
       action_list = [
           "aws-portal:*"
       ]
       resource_list = ["*"]
       condition = []
     }
   ]
 }
```
`policy_attachment_info`:


This map variable defines the mapping of IAM policy with the IAM role, and this module will create exclusive attachment of the IAM policies with respective IAM role. AWS Managed policies can also be included as shown below for S3. Each entry in this variable will create separate role-policy mappings. Keys for this map variable should be same as the keys for assume_role variable. 
 
```hcl
 policy_attachment_info = {
  master = [
    "arn:aws:iam::aws:policy/AmazonS3FullAccess",
    "custom_billing_portal",
    "custom_iam"
  ]
}
```
 
