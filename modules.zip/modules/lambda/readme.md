# Documentation
## Lambda Terraform module
 The primary purpose of the module is to setup lambda function.

## Usage
```hcl
module "lambda" {
  source = "../../../../modules/lambda/"
  application_name = var.application_name
  application_stage         = var.application_stage
  terraform_statefile = var.terraform_statefile
  created_by = var.created_by
  support_team = var.support_team
  service_role                = "rolearn"
  lambda_info = var.lambda_info
  security_group_info = module.security_group.group-id
  subnet_info = local.subnet_info
  efs_arn = module.efs.efs-access-point-arn
}
```
`application_name`, `application_stage`, `terraform_statefile`, `created_by`, `owner`, `cost_center`, `aws_account` are generic.

There are three complex variables that are key to the functioning of this module.  They are the `lambda_info`, `efs_arn`, ``service_role`

This map variable defines the trust relationship of the IAM role. We can include multiple entries inside this variable if we need multiple roles. 
```hcl
lambda_info = {
  lambda-function-name = {
    handler = "handler.hanlder"
    s3_bucket = "frk-s3-build-artifact"
    s3_key = "location/in-s3/zipfile.zip"
    runtime = "python3.7"
    reserved_concurrent_executions = "-1"
    timeout = "900"
    memory_size = "3000"
    event_mapping = []
    environment_variables = {
      "ENV1" = "VALUE",
    }
    efs_list = [
      "efslist"
    ]
    subnet_list = [
      "private_a",
      "private_b",
      "private_c"
    ]
    security_group_list = [
      "sg1"
    ]
    layer_list = []
  },
    another-lambda-function-name = {
    handler = "handler.handler"
    s3_bucket = "frk-s3-build-artifact"
    s3_key = "location/in-s3/zipfile.zip"
    runtime = "python3.7"
    reserved_concurrent_executions = "-1"
    timeout = "900"
    memory_size = "3000"
    event_mapping = []
    environment_variables = {
      "ENV1" = "VALUE",
    }
    efs_list = [
      "efslist"
    ]
    subnet_list = [
      "private_a",
      "private_b",
      "private_c"
    ]
    security_group_list = [
      "sg1"
    ]
    layer_list = []
  },
}
```