# Documentation
## DocumentDB Terraform module
 The primary purpose of the module is to create RDS database instance in AWS. 

## Usage
```hcl
module "postgres" {
  source                      = "../../modules/rds/"
  application_name         = var.application_name
  application_stage        = var.application_stage
  terraform_statefile      = var.terraform_statefile
  created_by               = var.created_by
  support_team             = var.support_team
  biz_division             = var.biz_division
  appid                    = var.appid
  deptcode                 = var.deptcode
  rds_build_info              = var.rds_build_info_postgres
  #security_group_ids          = module.security_group.group-id["dedb"]
  #subnet_id_list              = var.private_subnet_id_list
  security_group_ids          =  "sg-062ee7b55108b2947"
  subnet_id_list              = ["subnet-0f66ef51ad23770bf","subnet-03617152f0462f064"]
}

```
`application_name`, `application_stage`, `terraform_statefile`, `created_by`, `support_team`, `biz_division`, `appid`, `deptcode` are generic.

 There are three complex variables that are key to the functioning of this module.  They are the `subnet_id_list`, `security_group_ids`, `rds_build_info`. Since the top-level is a hash, the top-level hash keys need to be unique.

`subnet_id_list`:

This map variable defines the subnet where the database needs to be provisioned. 
```hcl
subnet_id_list=["subnetid1","subnetid2"]
```
`security_group_ids`:

This map variable defines security groups id for the database instances.

```hcl
security_group_ids=["sg-id1","sg-id2"] 
```
`rds_build_info_postgres`:

This map variable defines the configuration and properties for documendb instance. 
 
```hcl
rds_build_info_postgres = {
  sample-postgres-database = {
    database = {
      engine                      = "postgres"
      snapshot_identifier         = "sample-postgres-database"
      engine_version              = "12.7"
      port                        = 5432
      instance_class              = "db.t2.micro"
      apply_immediately           = false
      storage_type                = "gp2"
      allocated_storage           = 50
      max_allocated_storage       = 320
      multi_az                    = true 
      dbname                      = "dldb"
      dbusername                  = "root"
      dbpassword                  = "changeme"
      backup_retention_period     = 7
      backup_window               = "03:00-04:00"
      auto_minor_version_upgrade  = true
      maintenance_window          = "Sun:05:00-Sun:06:00"
      storage_encrypted           = true
      deletion_protection         = true
      skip_final_snapshot         = false
      final_snapshot_identifier   = "sample-postgres-database-final-backup"
      logs_exports                = ["postgresql"]
      #kms_key_id                  = ""
      #domain                       = "domainid"

    }
    db-parameters-info = {
      family                      = "postgres12"
      description                 = "parameter group for sample-postgres-database"
    }
    db-parameters = [
      {
        name  = "log_connections"
        value = "1"
      }
    ]
 }
}
```
 
