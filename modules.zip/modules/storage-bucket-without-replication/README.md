# Documentation
## AWS S3 bucket Terraform module
The primary purpose of the module is to create [S3 Bucket](https://docs.aws.amazon.com/AmazonS3/latest/userguide/Welcome.html) on AWS.
It provides the capability to create multiple buckets from a single module.

## Usage
```hcl
module "s3" {
  source                      = "../../../modules/storage-bucket-without-replication/"
  aws_account                 = var.aws_account
  FRK_AppIDName               = var.application_name
  FRK_Environment             = var.application_stage
  FRK_BizDivision             = var.biz_division
  FRK_AppID                   = var.appid
  FRK_DeptCode                = var.deptcode
  terraform_statefile         = var.terraform_statefile
  FRK_CreatedBy               = var.created_by
  FRK_SupportGroup            = var.support_team
  bucket_configuration        = var.bucket_configuration
  bucket_policy               = var.bucket_policy
  iam_target_account_number   = var.aws_account
  kms_arn                     = {}
  region                      = var.region
}

```

`bucket_configuration`, `bucket_policy` are the variables that are key to the functioning of this module.

`bucket_configuration`:

This is a map variable that contains details about the S3 buckets. Each entry in this variable will create seperate S3 bucket in AWS.
The following are the arguments in each bucket:

+ `block_public_acls` - Whether Amazon S3 should block public ACLs for this bucket. 
+ `ignore_public_acls` - Whether Amazon S3 should ignore public ACLs for this bucket. 
+ `block_public_policy` - Whether Amazon S3 should block public bucket policies for this bucket.
+ `versioning` - Whether S3 versioning is enabled or disabled.
+ `restrict_public_buckets` - Whether Amazon S3 should restrict public bucket policies for this bucket. 
+ `sse_algorithm`- Encryption method 
+ `lifecycle_rules` - s3 lifecycle policy

```hcl
bucket_configuration = {
  config-bucket = {
    block_public_acls       = true
    ignore_public_acls      = true
    block_public_policy     = true
    versioning              = false
    restrict_public_buckets = true
    sse_algorithm           = "AES256"
    lifecycle_rules         = [      
    {
        id = "base"
        prefix = ""
        abort_incomplete_multipart_upload_days = "7"
        transition_list = [
          {
            days = 14
            storage_class = "DEEP_ARCHIVE"
          }
        ]
        noncurrent_version_transition_list = [
          {
            days = 14
            storage_class = "DEEP_ARCHIVE"
          }
        ]
        expiration_days = 730
        noncurrent_version_expiration_days = 730
    }
    ]
  }
}
```

`bucket_policy`:
This map variable defines resource based S3 bucket policy for each S3 bucket 

 ```hcl
 
bucket_policy = {
  config-bucket = [
    {
      action_list = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:PutObjectAcl"
      ]
      principal_list = [
        {
          identifier_list = [
            "arn:aws:iam::999999999999:role/jenkins-dev-master",
            "arn:aws:iam::999999999999:role/jenkins-dev-agent",
            "arn:aws:iam::999999999999:root"
          ]
          type = "AWS"
        }
      ]
    }
  ]
}

```

For more details visit [here](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket).
